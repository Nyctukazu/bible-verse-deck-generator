rootProject.name = "versedeck"
